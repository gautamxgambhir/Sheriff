__version__ = '1.1'

def version():
    return __version__

__all__ = ['gui', 'version']