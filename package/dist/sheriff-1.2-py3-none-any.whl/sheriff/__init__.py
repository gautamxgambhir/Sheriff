__version__ = '1.2'

def version():
    return __version__

__all__ = ['gui', 'version']