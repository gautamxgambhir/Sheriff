__version__ = '1.4'

def version():
    return __version__

__all__ = ['gui', 'version']