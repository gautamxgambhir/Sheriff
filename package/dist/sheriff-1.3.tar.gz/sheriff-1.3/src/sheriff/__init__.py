__version__ = '1.3'

def version():
    return __version__

__all__ = ['gui', 'version']